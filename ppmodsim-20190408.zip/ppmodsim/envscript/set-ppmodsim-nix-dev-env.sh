## Source dev env settings for ppmodsim
## Under Linux environmnet
export PPMODSIM_ROOT=$PWD
export PPMODSIM_INSTALL=$PWD/install
export PATH=$PWD/install/bin:$PATH
export LD_LIBRARY_PATH=$PWD/install/lib:$LD_LIBRARY_PATH
export PYTHONPATH=$PWD/ppmodsim-py/src:$PYTHONPATH