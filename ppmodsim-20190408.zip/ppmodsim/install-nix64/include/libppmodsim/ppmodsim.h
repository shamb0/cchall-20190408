
/* ppmodsim.h
 *
 * This file is part of ppmodsim.
 *
 * Example Simulator Implementation for Lotka-Volterra model using 
 * Euler's method
 * 
 * Types and API Intrface definition 
 */

/******************************************************************************
 * INCLUDES
 *****************************************************************************/
#include <stdint.h>
#include "ppmodsim_dbg.h"

#ifndef PPMODSIM_H
#define PPMODSIM_H

#ifdef __cplusplus
extern "C"
{
#endif

/******************************************************************************
* TYPE DEFINITIONS
*****************************************************************************/

typedef int32_t ppmodsimErr_t;
typedef uintptr_t ppmodsimHandle_t;

typedef enum
{
    PPMODSIM_ERRCODE_NOERROR = 0,        //!< No Error
    PPMODSIM_ERRCODE_CALLFAILURE = -1,   //!< Error Call Failure
    PPMODSIM_ERRCODE_SIMFAILED = -2,     //!< Error Simulation Failure
    PPMODSIM_ERRCODE_NOMEMORY = -3,      //!< Error No System Memory
    PPMODSIM_ERRCODE_INVALIDHANDLE = -4, //!< Error Invalid Simulaton Handle
    PPMODSIM_ERRCODE_INVALIDARG = -5     //!< Error Invalid Function Arguments
} ppmodsimErrCode_t;

typedef struct
{
    /*! TimeStamp List */
    double *timeStamp;
    /*! Prey List */
    double *prey;
    /*! Predator List */
    double *pred;
} ppmodsimDataObj_t;

typedef struct
{
    /*! Equation coefficient alpa */
    double alpha;
    /*! Equation coefficient beta */
    double beta;
    /*! Equation coefficient gamma */
    double gamma;
    /*! Equation coefficient delta */
    double delta;
} ppmodsimEqCfg_t;

/******************************************************************************
 * PUBLIC FUNCTIONS
******************************************************************************/
/*!
 * \brief Open Simulation Context
 * 
 * \param [out] p_handSim - Simulation handle
 *                        
 * \return #PPMODSIM_ERRCODE_NOERROR - successful, -ve value - Failure
 * \pre #ppmodsim_open() needs to be called before executing all below functions.
 *
 * \note
 *1. Allocated handle is freed via #ppmodsim_close()
 */
ppmodsimErr_t ppmodsim_open(ppmodsimHandle_t *p_handSim);

/*!
 * \brief Close Simulation Context
 * 
 * \param [in] handSim - Simulation handle
 *                        
 * \return #PPMODSIM_ERRCODE_NOERROR - successful, -ve value - Failure
 *
 * \note
 *1. All resources allocated for simulation are freed.
 */
ppmodsimErr_t ppmodsim_close(ppmodsimHandle_t handSim);

/*!
 * \brief Config Simulation Context For Simulation
 * 
 * \param [in] handSim      - Simulation handle
 * \param [in] p_stEqCfg    - Equation Coefficients
 * \param [in] preyT0       - Initial number of Prey
 * \param [in] predT0       - Initial number of Predator
 * \param [in] simStartT    - Simulation Start Time
 * \param [in] simStopT     - Simulation Stop Time
 * \param [in] stepDt       - Simulation Step Time
 *                        
 * \return #PPMODSIM_ERRCODE_NOERROR - successful, -ve value - Failure
 *
 * \note
 *1. Resource needed for holding simulation result is allocated here.
 */
ppmodsimErr_t ppmodsim_cfg(ppmodsimHandle_t handSim, ppmodsimEqCfg_t *p_stEqCfg,
                            uint32_t preyT0, uint32_t predT0,
                            double simStartT, double simStopT,
                            double stepDt);

/*!
 * \brief Run Simulation
 * 
 * \param [in] handSim - Simulation handle
 *                        
 * \return #PPMODSIM_ERRCODE_NOERROR - successful, -ve value - Failure
 *
 */
ppmodsimErr_t ppmodsim_run(ppmodsimHandle_t handSim);

/*!
 * \brief Get Simulation Results
 * 
 * \param [in]  handSim         - Simulation handle
 * \param [out] p_stOpSimRslt   - Simulation Result #ppmodsimDataObj_t
 * \param [out] p_ListLen       - Simulation Result element length
 *                        
 * \return #PPMODSIM_ERRCODE_NOERROR - successful, -ve value - Failure
 */
ppmodsimErr_t ppmodsim_getStatus(ppmodsimHandle_t handSim,
                                    ppmodsimDataObj_t *p_stOpSimRslt,
                                    uint32_t *p_ListLen);
                                    
#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* PPMODSIM_H */
