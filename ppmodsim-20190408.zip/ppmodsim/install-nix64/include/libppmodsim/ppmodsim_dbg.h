/* ppmodsim_dbg.h
 *
 * This file is part of ppmodsim.
 *
 * Example Simulator Implementation for Lotka-Volterra model using 
 * Euler's method
 * 
 * Debug Print Macros 
 */

/******************************************************************************
 * INCLUDES
 *****************************************************************************/
#include <stdio.h>

#ifndef PPMODSIM_DBG_H
#define PPMODSIM_DBG_H

#ifdef __cplusplus
    extern "C" {
#endif

/******************************************************************************
* DEFINES
*****************************************************************************/

#define DBG_MSG(_FMT_, ...) \
   fprintf(stdout,_FMT_,##__VA_ARGS__);

#define DBG_INFO(_FMT_, ...) \
   fprintf(stdout,"INFO > %s::%d > "_FMT_,__FUNCTION__,__LINE__,##__VA_ARGS__);

#define DBG_ERR(_FMT_, ...) \
   fprintf(stdout,"ERR > %s::%d > "_FMT_,__FUNCTION__,__LINE__,##__VA_ARGS__);

#define DBG_WARN(_FMT_, ...) \
   fprintf(stdout,"WARN > %s::%d > "_FMT_,__FUNCTION__,__LINE__,##__VA_ARGS__);

#ifdef __cplusplus
    }  /* extern "C" */
#endif

#endif /* PPMODSIM_DBG_H */
