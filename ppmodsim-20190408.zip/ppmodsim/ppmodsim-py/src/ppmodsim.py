#!/usr/bin/env python3
"""PPModSim Binding Layer.

    ppmodsim.py Python ctypes Wrapper for types & interfaces defined in ppmodsim.h
    to access functionality of libppmodsim.so

"""
import sys
import ctypes
import numpy
import os
from enum import IntEnum
from sys import platform as _platform

## TODO :: Is there better way to handle derivation of path ...
# Construct absolute path for lib to open
path = []
path.insert(0, os.getcwd())
path.append('install')

if _platform == "linux" or _platform == "linux2":
    path.append('lib')
    path.append('libppmodsim.so')
elif _platform == "win32" or _platform == "win64":
    path.append('bin')
    path.append('msys-ppmodsim-2.dll')

libabspath = os.path.sep.join(path)

# Open the shared object 
libppmodsim = ctypes.CDLL(libabspath)

# To reduce the indirection
_numpy_core_multiarray_int_asbuffer = numpy.core.multiarray.int_asbuffer
_ctypes_addressof = ctypes.addressof
_numpy_array = numpy.array
_numpy_frombuffer = numpy.frombuffer
_float_size = numpy.dtype(float).itemsize

# Access double array from C space to Python
# Mapping from ctypes memeory pointer to numpy array object
def numpy_from_pointer(cpointer, size):
    if sys.version_info.major < 3:
        return _numpy_frombuffer(_numpy_core_multiarray_int_asbuffer(
            _ctypes_addressof(cpointer.contents), size * _float_size))
    else:
        buf_from_mem = ctypes.pythonapi.PyMemoryView_FromMemory
        buf_from_mem.restype = ctypes.py_object
        buf_from_mem.argtypes = (ctypes.c_void_p, ctypes.c_int, ctypes.c_int)
        cbuffer = buf_from_mem(cpointer, size * _float_size, 0x200)
        return numpy.ndarray((size,), numpy.float, cbuffer, order='C')

# Class wrapper C Error Code enum
class CtypesEnum(IntEnum):
    """A ctypes-compatible IntEnum superclass."""
    @classmethod
    def from_param(cls, obj):
        return int(obj)

class PPModSimErrCode(CtypesEnum):
    PPMODSIM_ERRCODE_NOERROR        =  0
    PPMODSIM_ERRCODE_CALLFAILURE    = -1
    PPMODSIM_ERRCODE_SIMFAILED      = -2
    PPMODSIM_ERRCODE_NOMEMORY       = -3
    PPMODSIM_ERRCODE_INVALIDHANDLE  = -4
    PPMODSIM_ERRCODE_INVALIDARG     = -5

# Class wrapper to C struct PPModSimEquCfg_t
class PPModSimEquCfg(ctypes.Structure):
    _fields_ = [('alpha', ctypes.c_double), ('beta', ctypes.c_double), 
                    ('gamma', ctypes.c_double), ('delta', ctypes.c_double) ]

    def __repr__(self):
        return '({0}, {1}, {2}, {3})'.format(self.alpha, self.beta, self.gamma, self.delta )

# Class wrapper to C struct ppmodsimDataObj_t
class ppmodsimDataObj(ctypes.Structure):
    _fields_ = [('timeStamp', numpy.ctypeslib.ndpointer(dtype=numpy.float64)), ('prey', numpy.ctypeslib.ndpointer(dtype=numpy.float64)), 
                    ('pred', numpy.ctypeslib.ndpointer(dtype=numpy.float64)) ]

    def __repr__(self):
        return '({0}, {1}, {2} )'.format(self.timeStamp, self.prey, self.pred )


# Util function to wrapper to C function & return Python function object
def wrap_function(lib, funcname, restype, argtypes):
    """Simplify wrapping ctypes functions"""
    func = lib.__getattr__(funcname)
    func.restype = restype
    func.argtypes = argtypes
    return func

# Python function object mapping corresponding C functions in ppmodsim.h
ppmodsim_open = wrap_function(libppmodsim, 'ppmodsim_open', PPModSimErrCode, [ctypes.POINTER(ctypes.c_uint)])

ppmodsim_close = wrap_function(libppmodsim, 'ppmodsim_close', PPModSimErrCode, [ctypes.c_uint])

ppmodsim_cfg = wrap_function(libppmodsim, 'ppmodsim_cfg', PPModSimErrCode, 
                                    [ctypes.c_uint, ctypes.POINTER(PPModSimEquCfg), ctypes.c_uint, ctypes.c_uint, 
                                        ctypes.c_double, ctypes.c_double, ctypes.c_double])

ppmodsim_run = wrap_function(libppmodsim, 'ppmodsim_run', PPModSimErrCode, [ctypes.c_uint])

ppmodsim_getStatus = wrap_function(libppmodsim, 'ppmodsim_getStatus', PPModSimErrCode, 
                                        [ctypes.c_uint , ctypes.POINTER(ppmodsimDataObj), ctypes.POINTER(ctypes.c_uint)])

