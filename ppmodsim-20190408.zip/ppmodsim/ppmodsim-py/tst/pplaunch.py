#!/usr/bin/env python3
"""PPModSim Launcher.

Usage:
     pplaunch.py [options]

Options:
    -h --help                           Show this screen.
    -c --use-config=<cfg_name>          Pick Simulation Config From Json file(Default dev).
    -x --disable-plot                   Disable Ploting of Simulation Output(Default Plot Enabled).
    -d --enable-dump=<finename.csv>     Dump Simulation Output To CSV file(Default File Dump Disabled).
"""
import sys
import ctypes
import numpy
import os
import json
from docopt import docopt
import matplotlib.pyplot as plt
import ppmodsim

def config( cliarguments ):

    cfgfilename = os.path.abspath(os.path.join(os.path.dirname(__file__), "config.json"))

    with open(cfgfilename, 'r') as f:
        simcfglist = json.load(f)

    simcfg = simcfglist.get(cliarguments.get('--use-config'))

    if simcfg is None:
        simcfg = simcfglist.get('dev')

    return simcfg


def plotsimresult( npa_simTimeStamp, npa_simPrey, npa_simPred ):
    print("Plotting Simulator Result")

    plt.plot(npa_simTimeStamp, npa_simPrey, 'g-', label='Prey')
    plt.plot(npa_simTimeStamp, npa_simPred, 'r-', label='Pred')

    plt.legend(loc='upper left')
    plt.xlabel('TimeStamp')
    plt.ylabel('Population')

    plt.show(block=True)

def dumpsimresult( dumpfilename, npa_simTimeStamp, npa_simPrey, npa_simPred ):
    numpy.savetxt(dumpfilename, npa_simTimeStamp, delimiter=",")
    numpy.savetxt(dumpfilename, npa_simPrey, delimiter=",")
    numpy.savetxt(dumpfilename, npa_simPred, delimiter=",")

def runmainsequence(cliarguments): 
    
    simcfg = config(cliarguments)    

    ###########################################################################
    print("Open Simulator Instance")

    handleSim = ctypes.c_uint(0)
    simErrCode = ppmodsim.ppmodsim_open( handleSim )

    print(simErrCode)

    ###########################################################################
    print("Cfg Simulator Instance")

    argEquCfg = ppmodsim.PPModSimEquCfg()

    argEquCfg.alpha     = simcfg.get('eqc-alpha')
    argEquCfg.beta      = simcfg.get('eqc-beta')
    argEquCfg.gamma     = simcfg.get('eqc-gamma')
    argEquCfg.delta     = simcfg.get('eqc-delta')

    simErrCode = ppmodsim.ppmodsim_cfg( handleSim, 
                            argEquCfg, simcfg.get('preyt0'), simcfg.get('predt0'), 
                            simcfg.get('start-t'), 
                            simcfg.get('stop-t'), 
                            simcfg.get('step-t'))

    print(simErrCode)

    ###########################################################################
    print("Run Simulation")
    
    simErrCode = ppmodsim.ppmodsim_run( handleSim )

    print(simErrCode)

    ###########################################################################
    print("Get Simulation Status")

    simDataObj = ppmodsim.ppmodsimDataObj()
    simDataObjLen = ctypes.c_uint(0)
    simErrCode = ppmodsim.ppmodsim_getStatus( handleSim, simDataObj, simDataObjLen)

    print(simErrCode)
    print(simDataObjLen.value)

    ###########################################################################
    print("Conv Simulation Result To numpy objects")

    npa_simTimeStamp = ppmodsim.numpy_from_pointer(simDataObj.timeStamp , simDataObjLen.value) 
    npa_simPrey = ppmodsim.numpy_from_pointer(simDataObj.prey , simDataObjLen.value)
    npa_simPred = ppmodsim.numpy_from_pointer(simDataObj.pred , simDataObjLen.value)

    ###########################################################################
    if cliarguments.get('--disable-plot') is False:
        plotsimresult( npa_simTimeStamp, npa_simPrey, npa_simPred)
    else:
        print("Simulation Result Plot Disabled")

    ###########################################################################
    dumpfilename = cliarguments.get('--enable-dump')

    if (dumpfilename):
        dumpsimresult( dumpfilename, npa_simTimeStamp, npa_simPrey, npa_simPred)

    ###########################################################################
    print("Close Simulation")

    simErrCode = ppmodsim.ppmodsim_close( handleSim )

    print(simErrCode)

if __name__ == '__main__':
    cliarguments = docopt(__doc__, version='0.1.1rc')
    print(cliarguments)

    runmainsequence(cliarguments)