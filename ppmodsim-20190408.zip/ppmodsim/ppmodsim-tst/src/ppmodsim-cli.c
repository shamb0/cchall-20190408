/* ppmodsim-lvmodel-eulermtd-impl.c
 *
 * This file is part of ppmodsim.
 *
 * Example Simulator Implementation for Lotka-Volterra model using 
 * Euler's method
 * 
 * CLI App to test ppmodsim 
 */

/******************************************************************************
 * INCLUDES
 *****************************************************************************/
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>
#include <unistd.h>
#include "ppmodsim.h"

/******************************************************************************
 * INTERNAL TYPES
 *****************************************************************************/
typedef struct
{
    // Simulation Handler
    ppmodsimHandle_t handSim;

    // Simulation Cfg
    bool cfgOptionsValid;

    ppmodsimEqCfg_t stEqCfg;
    uint32_t preyT0;
    uint32_t predT0;
    double simStartT;
    double simStopT;
    double stepDt;

    // Simulation Output Dump file
    char *fileName;

} ppmodsimCliCntx_t;

/******************************************************************************
 * INTERNAL UTIL FUNCTIONS
 *****************************************************************************/

/*-----------------------------------------------------------------------------
 * FUNCTION     :   printUsage
 *
 * DESCRIPTION  :   Utils Function To Display Help/Usage Menu
 *
 * NOTES:       :   NA
 *
 *-----------------------------------------------------------------------------
 */
static void printUsage(void)
{
    // Reference Cli options ...
    // ppmodsim-cli -a 0.3 -b 0.2 -c 0.1 -d 0.3 -x 100 -y 50 -i 100 -j 120 -k 0.2 -f simdump-sampv1.csv

    DBG_MSG("Usage                                                   : ppmodsim-cli [options]\n");
    DBG_MSG("Ex :: ppmodsim-cli -a 0.3 -b 0.2 -c 0.1 -d 0.3 -x 100 -y 50 -i 100 -j 200 -k 10 -f simdump-sampv1.csv \n");
    DBG_MSG("Options:\n");
    // equation coefficient
    DBG_MSG("-a <alpha +ve real value>                               : def{0.2} equation coeff (alfa)\n");
    DBG_MSG("-b <beta  +ve real value>                               : def{0.1} equation coeff (beta)\n");
    DBG_MSG("-c <gamma +ve real value>                               : def{0.1} equation coeff (gamma)\n");
    DBG_MSG("-d <delta +ve real value>                               : def{0.2} equation coeff (delta)\n");
    // initial number of prey and predators
    DBG_MSG("-x <preyT0>                                             : def{10} initial number of prey\n");
    DBG_MSG("-y <predT0>                                             : def{5} initial number of predators\n");
    // start , stop & step dt times for the simulation
    DBG_MSG("-i <startT>                                             : def{10} simulation start time\n");
    DBG_MSG("-j <stopT>                                              : def{20} simulation stop time\n");
    DBG_MSG("-k <stepT>                                              : def{2} time step dt\n");
    // file to dump simulation output csv fmt
    DBG_MSG("-f <file-name.csv>                                      : def{simdump.csv} file to dump simulation output in csv fmt\n");
}

/*-----------------------------------------------------------------------------
 * FUNCTION     :   ppmodsimcli_parseOptions
 *
 * DESCRIPTION  :   Utils Function To Parse CLI Arguments
 *
 * NOTES:       :   NA
 *
 *-----------------------------------------------------------------------------
 */
static int32_t ppmodsimcli_parseOptions(ppmodsimCliCntx_t *p_stSimCliCnt, int32_t argc, char **argv)
{
    int32_t funRetVal = 0;
    int32_t sysretVal;
    bool bLoopExit = false;
    bool bPrtArgs = true;

    if (argc < 2)
    {
        printUsage();
        bLoopExit = true;
        bPrtArgs = false;
        p_stSimCliCnt->cfgOptionsValid = false;
        funRetVal = -1;
    }
    else
    {
        // Update Defalut Values Here ...
        p_stSimCliCnt->cfgOptionsValid = true;
        p_stSimCliCnt->stEqCfg.alpha = 0.2;
        p_stSimCliCnt->stEqCfg.beta = 0.1;
        p_stSimCliCnt->stEqCfg.gamma = 0.1;
        p_stSimCliCnt->stEqCfg.delta = 0.2;

        p_stSimCliCnt->preyT0 = 10;
        p_stSimCliCnt->predT0 = 5;

        p_stSimCliCnt->simStartT = 10;
        p_stSimCliCnt->simStopT = 20;
        p_stSimCliCnt->stepDt = 2;

        p_stSimCliCnt->fileName = "simdump.csv";
    }

    // Iterate over the CLI options ...
    while (bLoopExit == false)
    {
        // Get next option
        sysretVal = getopt(argc, argv, "a:b:c:d:x:y:i:j:k:f:");

        if (sysretVal < 0)
        {
            // All options have been processed, leave loop
            bLoopExit = true;
            break;
        }
        else
        {
            switch (sysretVal)
            {
            case 'a':
                p_stSimCliCnt->stEqCfg.alpha = strtod(optarg, NULL);
                break;

            case 'b':
                p_stSimCliCnt->stEqCfg.beta = strtod(optarg, NULL);
                break;

            case 'c':
                p_stSimCliCnt->stEqCfg.gamma = strtod(optarg, NULL);
                break;

            case 'd':
                p_stSimCliCnt->stEqCfg.delta = strtod(optarg, NULL);
                break;

            case 'x':
                p_stSimCliCnt->preyT0 = strtol(optarg, NULL, 10);
                break;

            case 'y':
                p_stSimCliCnt->predT0 = strtol(optarg, NULL, 10);
                break;

            case 'i':
                p_stSimCliCnt->simStartT = strtod(optarg, NULL);
                break;

            case 'j':
                p_stSimCliCnt->simStopT = strtod(optarg, NULL);
                break;

            case 'k':
                p_stSimCliCnt->stepDt = strtod(optarg, NULL);
                break;

            case 'f':
                p_stSimCliCnt->fileName = optarg;
                break;

            default:
                DBG_MSG("Invalid Option %c \n", sysretVal);
            }
        }
    }

    // Starting the Simulation With Args ...
    if (bPrtArgs == true)
    {
        DBG_MSG("Starting the Simulation With Args ...\n");
        DBG_MSG("alpha = %lf, beta = %lf, gamma = %lf, delta = %lf \n",
                p_stSimCliCnt->stEqCfg.alpha,
                p_stSimCliCnt->stEqCfg.beta,
                p_stSimCliCnt->stEqCfg.gamma,
                p_stSimCliCnt->stEqCfg.delta);

        DBG_MSG("preyT0 x = %d predT0 y = %d \n",
                p_stSimCliCnt->preyT0,
                p_stSimCliCnt->predT0);

        DBG_MSG("StartT i = %lf StopT j = %lf StepT k = %lf \n",
                p_stSimCliCnt->simStartT,
                p_stSimCliCnt->simStopT,
                p_stSimCliCnt->stepDt);

        DBG_MSG("FileName :: %s \n", p_stSimCliCnt->fileName);
    }

    return (funRetVal);
}

/*-----------------------------------------------------------------------------
 * FUNCTION     :   ppmodsimcli_runSim
 *
 * DESCRIPTION  :   Utils Function To Launch Simulation
 *
 * NOTES:       :   NA
 *
 *-----------------------------------------------------------------------------
 */
static int32_t ppmodsimcli_runSim(ppmodsimCliCntx_t *p_stSimCliCnt)
{
    int32_t funRetVal = 0;
    ppmodsimErr_t simRetVal;

    simRetVal = ppmodsim_open(&p_stSimCliCnt->handSim);

    if (simRetVal != PPMODSIM_ERRCODE_NOERROR)
    {
        DBG_ERR("ppmodsim_open() failed ret(%d)\n", simRetVal);
        funRetVal = -1;
    }
    else
    {
        DBG_INFO("ppmodsim_open() Done ret(%d)\n", simRetVal);

        simRetVal = ppmodsim_cfg(p_stSimCliCnt->handSim, &p_stSimCliCnt->stEqCfg,
                                 p_stSimCliCnt->preyT0,
                                 p_stSimCliCnt->predT0,
                                 p_stSimCliCnt->simStartT,
                                 p_stSimCliCnt->simStopT,
                                 p_stSimCliCnt->stepDt);

        if (simRetVal != PPMODSIM_ERRCODE_NOERROR)
        {
            DBG_ERR("ppmodsim_cfg() failed ret(%d)\n", simRetVal);
            funRetVal = -1;
        }
        else
        {
            DBG_INFO("ppmodsim_cfg() Done ret(%d)\n", simRetVal);

            simRetVal = ppmodsim_run(p_stSimCliCnt->handSim);

            if (simRetVal != PPMODSIM_ERRCODE_NOERROR)
            {
                DBG_ERR("ppmodsim_run() failed ret(%d)\n", simRetVal);
                funRetVal = -1;
            }
            else
            {
                DBG_INFO("ppmodsim_run() Done ret(%d)\n", simRetVal);
            }
        }
    }

    return (funRetVal);
}

/*-----------------------------------------------------------------------------
 * FUNCTION     :   ppmodsimcli_dumpSimResult
 *
 * DESCRIPTION  :   Utils Function To Dump Simulation Result TO CSV File
 *
 * NOTES:       :   NA
 *
 *-----------------------------------------------------------------------------
 */
static int32_t ppmodsimcli_dumpSimResult(ppmodsimCliCntx_t *p_stSimCliCnt)
{
    int32_t itrIndx = 0;
    int32_t funRetVal = 0;
    ppmodsimErr_t simRetVal;
    int32_t dblkIndx;
    double *p_dblkStartOff = NULL;

    FILE *handDumpFile = NULL;

    // Simulation Output
    ppmodsimDataObj_t stSimOpObj;
    uint32_t sizeSimOpList = 0x00;

    simRetVal = ppmodsim_getStatus(p_stSimCliCnt->handSim, &(stSimOpObj),
                                   &(sizeSimOpList));

    if ((simRetVal != PPMODSIM_ERRCODE_NOERROR) ||
        (sizeSimOpList == 0x00))
    {
        DBG_ERR("ppmodsim_getStatus() failed ret(%d) listlen(%d) \n",
                simRetVal,
                sizeSimOpList);
        funRetVal = -1;
    }
    else
    {
        DBG_INFO("Dumping Simulation out Len(%d) to File (%s) \n",
                 sizeSimOpList,
                 p_stSimCliCnt->fileName);

        handDumpFile = fopen(p_stSimCliCnt->fileName, "w");

        if (handDumpFile == NULL)
        {
            DBG_ERR("fopen() failed Unable to open file (%s) \n",
                    p_stSimCliCnt->fileName);
        }
        else
        {
            // Printing to the file
            for (dblkIndx = 0x00; dblkIndx < 0x03; dblkIndx++)
            {

                switch (dblkIndx)
                {
                case 0:
                {
                    p_dblkStartOff = &stSimOpObj.timeStamp[0x00];
                    fprintf(handDumpFile, "TimeStamp,");
                }
                break;

                case 1:
                {
                    p_dblkStartOff = &stSimOpObj.prey[0x00];
                    fprintf(handDumpFile, "Prey,");
                }
                break;

                case 2:
                {
                    p_dblkStartOff = &stSimOpObj.pred[0x00];
                    fprintf(handDumpFile, "pred,");
                }
                break;
                default:
                    break;
                }

                for (itrIndx = 0x00; itrIndx < sizeSimOpList; itrIndx++)
                {
                    fprintf(handDumpFile, "%lf,", p_dblkStartOff[itrIndx]);
                }

                fprintf(handDumpFile, "\n");
            }

            fclose(handDumpFile);

            DBG_INFO("File Dump Done\n");
        }
    }

    return (funRetVal);
}

/*-----------------------------------------------------------------------------
 * FUNCTION     :   ppmodsimcli_resetSim
 *
 * DESCRIPTION  :   Utils Function To Close/Reset Simulation Context
 *
 * NOTES:       :   NA
 *
 *-----------------------------------------------------------------------------
 */
static int32_t ppmodsimcli_resetSim(ppmodsimCliCntx_t *p_stSimCliCnt)
{
    int32_t funRetVal = 0;
    ppmodsimErr_t simRetVal;

    simRetVal = ppmodsim_close(p_stSimCliCnt->handSim);

    if (simRetVal != PPMODSIM_ERRCODE_NOERROR)
    {
        DBG_ERR("ppmodsim_close() failed ret(%d)\n", simRetVal);
        funRetVal = -1;
    }
    else
    {
        DBG_INFO("Closed Simulation\n");
    }

    return (funRetVal);
}

/******************************************************************************
 * PUBLIC FUNCTIONS
 *****************************************************************************/
int32_t main(int32_t argc, char **argv)
{
    int32_t funRetVal = 0;
    ppmodsimCliCntx_t stSimCliCnt;

    // Parse Cli-option
    funRetVal = ppmodsimcli_parseOptions(&stSimCliCnt, argc, argv);

    if (stSimCliCnt.cfgOptionsValid == false)
    {
        DBG_MSG("Invalid Args Exit !!!\n");
    }
    else
    {

        DBG_MSG("Launching Simulation !!!\n");

        // if options ok launch sim
        funRetVal = ppmodsimcli_runSim(&stSimCliCnt);

        // if Simulation ok dump the result to CSV file
        if (funRetVal == 0)
        {
            DBG_MSG("Dumping Simulation Output !!!\n");

            funRetVal = ppmodsimcli_dumpSimResult(&stSimCliCnt);

            if (funRetVal < 0)
            {
                DBG_MSG("Something Went Wrong Unable to Dump ...!!!\n");
            }
        }

        // Terminate the simulator
        funRetVal = ppmodsimcli_resetSim(&stSimCliCnt);

        DBG_MSG("App Done Exit ...!!!\n");
    }

    return 0;
}
