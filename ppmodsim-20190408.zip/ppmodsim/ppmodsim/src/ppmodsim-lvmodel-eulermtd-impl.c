/* ppmodsim-lvmodel-eulermtd-impl.c
 *
 * This file is part of ppmodsim.
 *
 * Example Simulator Implementation for Lotka-Volterra model using 
 * Euler's method
 * 
 * Types and API Intrface Implementation 
 */

/******************************************************************************
 * INCLUDES
 ******************************************************************************/
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <math.h>
#include "ppmodsim.h"

/******************************************************************************
 * DEFINES
 *****************************************************************************/
// Macros to Check integrity of Simulation Context Handle
#define PPMODSIM_CNTX_HEAD_MAGIC (0xCAFED00D)
#define PPMODSIM_CNTX_TAIL_MAGIC (0xFEEDC0DE)

#define PPMODSIM_CNTX_VALID(_X_)                       \
    (((_X_->magicHead) == PPMODSIM_CNTX_HEAD_MAGIC) && \
     ((_X_->magicTail) == PPMODSIM_CNTX_TAIL_MAGIC))

/******************************************************************************
 * INTERNAL TYPES
 *****************************************************************************/
// type to define the Simulation Context
typedef struct
{
    // Head Magic code for Integrity of Handle
    uint32_t magicHead;

    // Simulation Cfg
    ppmodsimEqCfg_t stEqCfg;
    uint32_t preyT0;
    uint32_t predT0;
    double simStartT;
    double simStopT;
    double stepDt;

    uint32_t runSimIterationMax;

    // Container for Simulation Output
    double *p_SimOpObj;

    ppmodsimDataObj_t stSimOpDataFrame;

    // Tail Magic code for Integrity of Handle
    uint32_t magicTail;

} ppmodsimCntx_t;

/******************************************************************************
 * PUBLIC FUNCTIONS
 *****************************************************************************/

/*-----------------------------------------------------------------------------
 * FUNCTION     :   ppmodsim_open
 *
 * DESCRIPTION  :   Open Simulation Context
 *
 * NOTES:       :   NA
 *
 *-----------------------------------------------------------------------------
 */
ppmodsimErr_t ppmodsim_open(ppmodsimHandle_t *p_handSim)
{
    ppmodsimErr_t retVal = PPMODSIM_ERRCODE_NOERROR;
    ppmodsimCntx_t *p_stSimCntx = NULL;

    // Check - Argument Integrity
    if (p_handSim == NULL)
    {
        DBG_ERR("InValid Arg p_handSim(%p) \n", p_handSim);
        retVal = PPMODSIM_ERRCODE_INVALIDARG;
    }

    // Allocate Simulation Context
    if (retVal == PPMODSIM_ERRCODE_NOERROR)
    {
        p_stSimCntx = malloc(sizeof(ppmodsimCntx_t));

        if (p_stSimCntx == NULL)
        {
            DBG_ERR("memory alloc failed size(%zu) \n", sizeof(ppmodsimCntx_t));
            retVal = PPMODSIM_ERRCODE_NOMEMORY;
        }
        else
        {
            // Reset Simulation Context
            p_stSimCntx->magicHead = PPMODSIM_CNTX_HEAD_MAGIC;
            p_stSimCntx->magicTail = PPMODSIM_CNTX_TAIL_MAGIC;
            p_stSimCntx->p_SimOpObj = NULL;

            // Return the allocated context as handle to user
            *p_handSim = (ppmodsimHandle_t)p_stSimCntx;
        }
    }

    return (retVal);
}

/*-----------------------------------------------------------------------------
 * FUNCTION     :   ppmodsim_close
 *
 * DESCRIPTION  :   Close Simulation Context
 *
 * NOTES:       :   NA
 *
 *-----------------------------------------------------------------------------
 */
ppmodsimErr_t ppmodsim_close(ppmodsimHandle_t handSim)
{
    ppmodsimErr_t retVal = PPMODSIM_ERRCODE_NOERROR;
    ppmodsimCntx_t *p_stSimCntx = (ppmodsimCntx_t *)handSim;

    // Check - Handle Integrity
    if (!(PPMODSIM_CNTX_VALID(p_stSimCntx)))
    {
        DBG_ERR("InValid Handle Head(0x%x) Tail (0x%x) \n", p_stSimCntx->magicHead, p_stSimCntx->magicTail);
        retVal = PPMODSIM_ERRCODE_INVALIDHANDLE;
    }

    // Deallocate Simulation Context
    if (retVal == PPMODSIM_ERRCODE_NOERROR)
    {
        // De allocate the Simulation Output Buffer
        if (p_stSimCntx->p_SimOpObj != NULL)
        {
            free(p_stSimCntx->p_SimOpObj);
        }

        free(p_stSimCntx);

        p_stSimCntx = NULL;
    }

    return (retVal);
}

/*-----------------------------------------------------------------------------
 * FUNCTION     :   ppmodsim_cfg
 *
 * DESCRIPTION  :   Config Simulation Context For Simulation
 *
 * NOTES:       :   NA
 *
 *-----------------------------------------------------------------------------
 */
ppmodsimErr_t ppmodsim_cfg(ppmodsimHandle_t handSim, ppmodsimEqCfg_t *p_stEqCfg, uint32_t preyT0,
                           uint32_t predT0, double simStartT, double simStopT, double stepDt)
{

    ppmodsimErr_t retVal = PPMODSIM_ERRCODE_NOERROR;
    ppmodsimCntx_t *p_stSimCntx = (ppmodsimCntx_t *)handSim;

    // Check - Handle Integrity
    if (!(PPMODSIM_CNTX_VALID(p_stSimCntx)))
    {
        DBG_ERR("InValid Handle Head(0x%x) Tail (0x%x) \n", p_stSimCntx->magicHead, p_stSimCntx->magicTail);
        retVal = PPMODSIM_ERRCODE_INVALIDHANDLE;
    }

    // Check Argument Integrity
    if (simStopT < simStartT)
    {
        DBG_ERR("InValid Arg simStopT(%lf) simStartT(%lf) \n", simStopT, simStartT);
        retVal = PPMODSIM_ERRCODE_INVALIDARG;
    }

    // Cfg Simulation Context
    if (retVal == PPMODSIM_ERRCODE_NOERROR)
    {
        p_stSimCntx->runSimIterationMax = (uint32_t)((simStopT - simStartT) / stepDt);

        // Allocate Buffer for Simulation Output
        p_stSimCntx->p_SimOpObj = (double *)malloc(sizeof(double) * 0x03 * p_stSimCntx->runSimIterationMax);

        if (p_stSimCntx->p_SimOpObj == NULL)
        {
            DBG_ERR("memory alloc failed size(%zu) \n",
                    (sizeof(ppmodsimDataObj_t) * p_stSimCntx->runSimIterationMax));

            retVal = PPMODSIM_ERRCODE_NOMEMORY;
        }
        else
        {
            // Split the buffer for each element in Simulation Result data frame
            // 3 x n array
            p_stSimCntx->stSimOpDataFrame.timeStamp = p_stSimCntx->p_SimOpObj;
            p_stSimCntx->stSimOpDataFrame.prey = (double *)((uintptr_t)p_stSimCntx->p_SimOpObj +
                                                            (sizeof(double) * 0x01 * p_stSimCntx->runSimIterationMax));
            p_stSimCntx->stSimOpDataFrame.pred = (double *)((uintptr_t)p_stSimCntx->p_SimOpObj +
                                                            (sizeof(double) * 0x02 * p_stSimCntx->runSimIterationMax));
        }
    }

    if (retVal == PPMODSIM_ERRCODE_NOERROR)
    {
        // Looks all good
        // Update the simulation config
        memcpy((void *)(&(p_stSimCntx->stEqCfg)), p_stEqCfg,
               sizeof(ppmodsimEqCfg_t));

        p_stSimCntx->preyT0 = preyT0;
        p_stSimCntx->predT0 = predT0;
        p_stSimCntx->simStartT = simStartT;
        p_stSimCntx->simStopT = simStopT;
        p_stSimCntx->stepDt = stepDt;

        p_stSimCntx->stSimOpDataFrame.timeStamp[0x00] = simStartT;
        p_stSimCntx->stSimOpDataFrame.prey[0x00] = preyT0;
        p_stSimCntx->stSimOpDataFrame.pred[0x00] = predT0;
    }

    return (retVal);
}

/*-----------------------------------------------------------------------------
 * FUNCTION     :   ppmodsim_run
 *
 * DESCRIPTION  :   Run Simulation
 *
 * NOTES:       :   NA
 *
 *-----------------------------------------------------------------------------
 */
ppmodsimErr_t ppmodsim_run(ppmodsimHandle_t handSim)
{
    ppmodsimErr_t retVal = PPMODSIM_ERRCODE_NOERROR;
    ppmodsimCntx_t *p_stSimCntx = (ppmodsimCntx_t *)handSim;
    uint32_t iterIndex;
    double compuPrey;
    double compuPred;

    // Check - Handle Integrity
    if (!(PPMODSIM_CNTX_VALID(p_stSimCntx)))
    {
        DBG_ERR("InValid Handle Head(0x%x) Tail (0x%x) \n", p_stSimCntx->magicHead, p_stSimCntx->magicTail);
        retVal = PPMODSIM_ERRCODE_INVALIDHANDLE;
    }

    // Check Simulation Context State
    if (p_stSimCntx->p_SimOpObj == NULL)
    {
        DBG_ERR("InValid Arg p_SimOpObj(%p)\n", p_stSimCntx->p_SimOpObj);
        retVal = PPMODSIM_ERRCODE_CALLFAILURE;
    }

    // Run Simulation Iteration
    if (retVal == PPMODSIM_ERRCODE_NOERROR)
    {

#if 0
        
        // algo-1 Based on wiki
        // https://en.wikipedia.org/wiki/Lotka%E2%80%93Volterra_equations

        for( iterIndex = 1; iterIndex < p_stSimCntx->runSimIterationMax; iterIndex++ )
        {

            // compuPrey => dx/dt = (alpha * x) - (beta * x * y )
            // compuPred => dy/dt = (delta * x * y) - ( gamma * y)

            compuPrey = ( p_stSimCntx->stEqCfg.alpha * p_stSimCntx->stSimOpDataFrame.prey[iterIndex -1] ) - \
                         ( p_stSimCntx->stEqCfg.beta * p_stSimCntx->stSimOpDataFrame.prey[iterIndex -1] * \
                            p_stSimCntx->stSimOpDataFrame.pred[iterIndex -1] );

            compuPred = ( p_stSimCntx->stEqCfg.delta * p_stSimCntx->stSimOpDataFrame.prey[iterIndex -1] * \
                            p_stSimCntx->stSimOpDataFrame.pred[iterIndex -1] ) - \
                            (p_stSimCntx->stEqCfg.gamma * p_stSimCntx->stSimOpDataFrame.pred[iterIndex -1]);            

            p_stSimCntx->stSimOpDataFrame.timeStamp[iterIndex] = p_stSimCntx->stSimOpDataFrame.timeStamp[iterIndex-1] + \
                                                                p_stSimCntx->stepDt;
            p_stSimCntx->stSimOpDataFrame.prey[iterIndex] = compuPrey;
            p_stSimCntx->stSimOpDataFrame.pred[iterIndex] = compuPred;
        }
#endif

#if 1
        // algo-2 Based on Ref1
        // https://math.stackexchange.com/questions/1190310/solving-lotka-volterra-model-using-eulers-method

        for (iterIndex = 1; iterIndex < p_stSimCntx->runSimIterationMax; iterIndex++)
        {

            /*            
            dp/dt = ap( 1 - p/K) - (bpq/(1+bp))
            dq/dt = mq( 1 - q/kp)
            pi = pi−1 + (( (0.2 * pi−1) (1 − ( pi−1 / 500 )) − (( 0.1 * pi−1 * qi−1 ) / ( 1 + ( 0.1 * pi−1)))) * 0.1 )
            qi = qi−1 + (( 0.1 * qi−1 * ( 1 − ( qi−1 / ( 0.2 * pi−1)))) * 0.1 )
            */

            compuPrey = p_stSimCntx->stSimOpDataFrame.prey[iterIndex - 1] +
                        (((p_stSimCntx->stEqCfg.alpha * p_stSimCntx->stSimOpDataFrame.prey[iterIndex - 1]) *
                              (1 - (p_stSimCntx->stSimOpDataFrame.prey[iterIndex - 1] / 500)) -
                          ((p_stSimCntx->stEqCfg.beta * p_stSimCntx->stSimOpDataFrame.prey[iterIndex - 1] * p_stSimCntx->stSimOpDataFrame.pred[iterIndex - 1]) /
                           (1 + (p_stSimCntx->stEqCfg.beta * p_stSimCntx->stSimOpDataFrame.prey[iterIndex - 1])))) *
                         p_stSimCntx->stEqCfg.beta);

            compuPred = p_stSimCntx->stSimOpDataFrame.pred[iterIndex - 1] +
                        ((p_stSimCntx->stEqCfg.gamma * p_stSimCntx->stSimOpDataFrame.pred[iterIndex - 1] *
                          (1 - (p_stSimCntx->stSimOpDataFrame.pred[iterIndex - 1] /
                                (p_stSimCntx->stEqCfg.delta * p_stSimCntx->stSimOpDataFrame.prey[iterIndex - 1])))) *
                         p_stSimCntx->stEqCfg.gamma);

            p_stSimCntx->stSimOpDataFrame.timeStamp[iterIndex] = p_stSimCntx->stSimOpDataFrame.timeStamp[iterIndex - 1] +
                                                                 p_stSimCntx->stepDt;

            p_stSimCntx->stSimOpDataFrame.prey[iterIndex] = compuPrey;
            p_stSimCntx->stSimOpDataFrame.pred[iterIndex] = compuPred;
        }

#endif

#if 0

        // algo-3 Sin & Cousine Generator 
        // To Validate Simulation framework & data integrity of buffer
        (void) compuPrey;
        (void) compuPred;
        double constPI = ( 3.14159265 / 180 );

        for( iterIndex = 1; iterIndex < p_stSimCntx->runSimIterationMax; iterIndex++ )
        {

            p_stSimCntx->stSimOpDataFrame.timeStamp[iterIndex] = iterIndex;
            p_stSimCntx->stSimOpDataFrame.prey[iterIndex] = sin( iterIndex * constPI);
            p_stSimCntx->stSimOpDataFrame.pred[iterIndex] = cos( iterIndex * constPI);

        }

#endif
    }

    return (retVal);
}

/*-----------------------------------------------------------------------------
 * FUNCTION     :   ppmodsim_getStatus
 *
 * DESCRIPTION  :   Get Simulation Results
 *
 * NOTES:       :   NA
 *
 *-----------------------------------------------------------------------------
 */
ppmodsimErr_t ppmodsim_getStatus(ppmodsimHandle_t handSim,
                                 ppmodsimDataObj_t *p_stOpSimRslt,
                                 uint32_t *p_ListLen)
{
    ppmodsimErr_t retVal = PPMODSIM_ERRCODE_NOERROR;
    ppmodsimCntx_t *p_stSimCntx = (ppmodsimCntx_t *)handSim;

    // Check - Handle Integrity
    if (!(PPMODSIM_CNTX_VALID(p_stSimCntx)))
    {
        DBG_ERR("InValid Handle Head(0x%x) Tail (0x%x) \n", p_stSimCntx->magicHead, p_stSimCntx->magicTail);
        retVal = PPMODSIM_ERRCODE_INVALIDHANDLE;
    }

    // Check Argument Integrity
    if ((p_stOpSimRslt == NULL) || (p_ListLen == NULL))
    {
        DBG_ERR("InValid Arg p_stOpSimRslt(%p) p_ListLen(%p) \n", p_stOpSimRslt, p_ListLen);
        retVal = PPMODSIM_ERRCODE_INVALIDARG;
    }

    // Check Simulation Context State
    if (p_stSimCntx->p_SimOpObj == NULL)
    {
        DBG_ERR("InValid Arg p_SimOpObj(%p)\n", p_stSimCntx->p_SimOpObj);
        retVal = PPMODSIM_ERRCODE_CALLFAILURE;
    }

    if (retVal == PPMODSIM_ERRCODE_NOERROR)
    {
        // Looks all is good
        // Update the simulation status to user
        *p_ListLen = p_stSimCntx->runSimIterationMax;
        p_stOpSimRslt->timeStamp = p_stSimCntx->stSimOpDataFrame.timeStamp;
        p_stOpSimRslt->prey = p_stSimCntx->stSimOpDataFrame.prey;
        p_stOpSimRslt->pred = p_stSimCntx->stSimOpDataFrame.pred;
    }

    return (retVal);
}
