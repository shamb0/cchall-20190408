# Code Challenge Reference Implementation

---

## Code Challenge Description

1. Develop a C-library that implements simulation of prey and predator equation [wiki](https://en.wikipedia.org/wiki/Lotka%E2%80%93Volterra_equations) that compiles into a .so or .dll.

**Simulation should use forward Euler method with fixed time step dt.**

_Simulation takes as input:_

* equation coefficient (alfa, beta, delta, gamma)
* initial number of prey and predators
* start and stop times for the simulation
* time step dt

Returns:

* 2D array with first row as time variable for the time steps, second row as “prey” and third row as “predators”.

2. Write test program for the library in “C” that gets parameters from the command line and generates .CSV file with the simulation results.

3. Write a Python script that: 

* Reads parameters from a file or command line
* Uses ctypes module to call into the C-library produced in step 1 to get the results
* Generate a plot for the simulation result.

* Steps 1-3 may be performed on either Linux or Windows – your choice. As a final step demonstrate that the code can be compiled and run both on Linux and Windows. If time does not permit to do this – explain what steps are needed for the “other” platform in the README.
 
* Delivery expected (packaged into a “zip” or “tgz”):

- Source code with minimal comments including build system
- Binaries
- README  

---

## Screenshots

### Using Algo1
**algo-1 Based on wiki** [wiki](https://en.wikipedia.org/wiki/Lotka%E2%80%93Volterra_equations)

![](https://i.imgur.com/mHDfHZ4.png)

### Using Algo2
**algo-2 Based on Ref1** [Ref1](https://math.stackexchange.com/questions/1190310/solving-lotka-volterra-model-using-eulers-method)

![](https://i.imgur.com/RqeXBzN.png)

### Using sin generator (singen)

**algo-3 Sin & Cousine Generator**
_To Validate Simulation framework & data integrity of buffer_

![](https://i.imgur.com/ktXhtOv.png)

**Note** :: Choice of Simulation Algo is part of ppmodsim_run() function in file "ppmodsim\src\ppmodsim-lvmodel-eulermtd-impl.c". Plz refer function ppmodsim_run()
for details.

---

## QuickStart

### Requirements

#### Linux

- cmake  :: cmake version 3.x ( Tested on cmake version 3.5.1 )
- Linux GCC toolchain
- python :: Python 3.x ( Tested on Python 3.6.4 )
- python modules :: ctypes, numpy, matplotlib, json, docopt
  
#### Windows

- cmake  :: cmake version 3.x ( Tested on cmake version 3.10.2 )
- MSYS mingw64
  
    ```shell
    gcc --version
    gcc (Rev1, Built by MSYS2 project) 8.2.0
    Copyright (C) 2018 Free Software Foundation, Inc.
    This is free software; see the source for copying conditions.  There is NO
    warranty; not even for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    ```
- python :: Python 3.x ( Tested on Python 3.6.5 :: Anaconda, Inc. )
    
- python modules :: ctypes, numpy, matplotlib, json, docopt

### Howto Run Pre-Build images

#### Linux

```shell
cd <EXTRACTPATH>/ppmodsim
cp -R ./install-nix64 ./install
source ./envscript/set-ppmodsim-nix-dev-env.sh
python ./ppmodsim-py/tst/pplaunch.py -c algo2
```

#### Windows

```shell
cd <EXTRACTPATH>/ppmodsim
md install
xcopy /E  .\install-win64 .\install
.\envscript\set-ppmodsim-win-dev-env.bat
python ./ppmodsim-py/tst/pplaunch.py -c algo2
```

### Howto Build

#### Linux

```shell
cd <EXTRACTPATH>/ppmodsim
source ./envscript/set-ppmodsim-nix-dev-env.sh
mkdir build
cd build
cmake -DCMAKE_INSTALL_PREFIX=$PPMODSIM_INSTALL ..
make
make install
cd ..
python ./ppmodsim-py/tst/pplaunch.py -c algo2
```

#### Windows

```shell
cd <EXTRACTPATH>/ppmodsim
md build
.\envscript\set-ppmodsim-win-dev-env.bat
cd build
cmake -DCMAKE_INSTALL_PREFIX=../install ..
make
make install
cd ..
python ./ppmodsim-py/tst/pplaunch.py -c algo2
```

---

## Test App Help Message

### Test App in folder ppmodsim-tst (ppmodsim-cli)

```shell
λ ppmodsim-cli.exe
Usage                                                   : ppmodsim-cli [options]
Ex :: ppmodsim-cli -a 0.3 -b 0.2 -c 0.1 -d 0.3 -x 100 -y 50 -i 100 -j 200 -k 10 -f simdump-sampv1.csv
Options:
-a <alpha +ve real value>                               : def{0.2} equation coeff (alfa)
-b <beta  +ve real value>                               : def{0.1} equation coeff (beta)
-c <gamma +ve real value>                               : def{0.1} equation coeff (gamma)
-d <delta +ve real value>                               : def{0.2} equation coeff (delta)
-x <preyT0>                                             : def{10} initial number of prey
-y <predT0>                                             : def{5} initial number of predators
-i <startT>                                             : def{10} simulation start time
-j <stopT>                                              : def{20} simulation stop time
-k <stepT>                                              : def{2} time step dt
-f <file-name.csv>                                      : def{simdump.csv} file to dump simulation output in csv fmt
Invalid Args Exit !!!
```

### Test App in folder ppmodsim-py/tst (pplaunch.py)

```shell
λ python .\ppmodsim-py\tst\pplaunch.py -h

PPModSim Launcher.

Usage:
     pplaunch.py [options]

Options:
    -h --help                           Show this screen.
    -c --use-config=<cfg_name>          Pick Simulation Config From Json file(Default dev).
    -x --disable-plot                   Disable Ploting of Simulation Output(Default Plot Enabled).
    -d --enable-dump=<finename.csv>     Dump Simulation Output To CSV file(Default File Dump Disabled).
```

---
